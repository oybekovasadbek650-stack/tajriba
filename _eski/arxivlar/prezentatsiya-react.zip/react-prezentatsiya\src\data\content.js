/* ══════════════════════════════════════════════════════════════
   BUTUN MATN SHU YERDA. Prezentatsiyani o'zgartirish uchun
   faqat shu faylni tahrirlang — komponentlarga tegish shart emas.
   ══════════════════════════════════════════════════════════════ */

export const meta = {
  brand: 'Algora',
  event: 'Ilmiy-amaliy konferensiya · 2026',
  university: '[Universitet nomi]',
  title: "Sun'iy intellekt talaba o'zlashtirishini {9 haftada} qanday o'zgartiradi",
  lede: "Algora — ma'ruza matnini tushunadi, savol tuzadi, xatoni topadi va professorga real vaqtda hisobot beradi. Bu ish — o'zlashtirishni taxmindan raqamga aylantirish urinishi.",
  contacts: [
    { label: 'Taqdim etuvchi', value: '[Ism Familiya]' },
    { label: 'Ilmiy rahbar', value: '[F.I.SH., professor]' },
    { label: 'Kafedra', value: '[Kafedra nomi]' },
    { label: 'Guruh / yo\'nalish', value: '[0000-0000]' }
  ],
  email: '[ism@universitet.uz]'
};

export const problem = {
  kicker: '01 — Muammo',
  title: 'Baholash ikki oy kechikadi',
  cards: [
    { icon: '◴', h: 'Kech feedback', p: "Imtihon qog'ozi tekshirilganda talaba mavzuni allaqachon unutgan bo'ladi. Xatoni tuzatish oynasi yopilgan." },
    { icon: '▥', h: 'Yuqori ish yuklamasi', p: "120 varaqni qo'lda tekshirish — professor uchun 6 soat. Shu vaqtning 80% i takroriy, yaratuvchi bo'lmagan ish." },
    { icon: '◈', h: 'Yashirin qolganlar', p: 'Savol so\'ray olmagan talaba birinchi semestrning o\'zida chetda qoladi — va buni hech kim sezmaydi.' }
  ],
  note: "Markaziy gipoteza: xato {24 soat ichida} aytilsa, o'zlashtirish egri chizig'i ko'tariladi."
};

export const solution = {
  kicker: '02 — Yechim',
  title: 'Uch ishni bir vaqtda bajaradigan tizim',
  points: [
    { who: 'Talabaga', what: '"nima uchun noto\'g\'ri" tushuntirishi bilan darhol baholanuvchi test.' },
    { who: 'Professor uchun', what: "guruhning zaif mavzularini ko'rsatadigan issiq xarita." },
    { who: 'Fakultet uchun', what: "kontsepsiya darajasidagi solishtirma hisobot, ism-sharifsiz." }
  ],
  quote: 'AI baholamaydi — AI baholashni {tezlashtiradi}. Yakuniy qarov professorniki.',
  panel: {
    url: 'algora.uz/panel',
    question: 'Savol 7 · Termodinamikaning 2-qonuni',
    answer: 'Yopiq tizimda entropiya kamaymaydi.',
    why: "Siz izolyatsiyalangan holatni to'g'ri tanladingiz; 40% guruh shu savolda 1-qonun bilan aralashtirib yubordi.",
    meter: 78,
    caption: 'Guruh o\'rtacha natijasi {78%} · 3 talaba bu mavzuda xavf ostida'
  }
};

export const architecture = {
  kicker: '03 — Qanday ishlaydi',
  title: "Besh halqa, bitta yo'l",
  steps: [
    { n: 1, h: 'Kirish', p: 'PDF, audio, LMS' },
    { n: 2, h: "Bo'laklash", p: 'mavzu bloklari' },
    { n: 3, h: 'Model', p: 'LLM + rubrika' },
    { n: 4, h: 'Baholash', p: 'mezon bo\'yicha ball' },
    { n: 5, h: 'Hisobot', p: 'panel + eksport' }
  ],
  stack: ['Python 3.12', 'FastAPI', 'PostgreSQL', 'pgvector', 'Redis queue', 'Whisper', 'React 19', 'Docker']
};

export const results = {
  kicker: '04 — Natijalar',
  title: 'Pilot: 1 ta guruh, 9 hafta',
  stats: [
    { value: 9, suffix: '', label: 'hafta pilot' },
    { value: 142, suffix: '', label: 'talaba ishtirok etdi' },
    { value: 38, suffix: '%', label: "o'zlashtirish o'sishi" },
    { value: 6, suffix: '→0.4', label: 'soat tekshir vaqti' }
  ],
  note: 'Nazorat guruhi: 46 talaba, an\'anaviy baholash. Farq t-testida p < 0.01.',
  chart: {
    // Hafta 1→9, 0..100 shkalasi. Haqiqiy raqamlaringizni shu yerga qo'ying.
    ours: [52, 55, 57, 66, 70, 79, 83, 92, 95],
    control: [50, 51, 52, 53, 54, 55, 56, 57, 58],
    legend: ['Algora guruhi', 'Nazorat guruhi', 'Hafta 1 → 9']
  }
};

export const ethics = {
  kicker: '05 — Etika va ma\'lumot himoyasi',
  title: 'Model ism bilmaydi',
  cards: [
    { h: 'Anonimlashtirish', p: "Talaba ID — hash. Modelga ism-sharif, foto, telefon yetib bormaydi." },
    { h: 'Odamsiz yakun', p: 'AI taklif qilgan baho — professor bosmaguncha jurnalga yozilmaydi.' },
    { h: 'Ochiq rubrika', p: "Har baho qanday mezon bilan chiqqani talabaga ko'rsatiladi." },
    { h: 'Chetda saqlash', p: "Ma'lumot universitet serveridan tashqariga chiqmaydi." }
  ]
};

export const roadmap = {
  kicker: '06 — Kelajak',
  title: 'Keyingi 4 bosqich',
  steps: [
    { when: '2026 / I', what: "2-fakultetga kengaytirish, o'zbek + rus interfeysi." },
    { when: '2026 / II', what: "Ovozli savol-javob: ma'ruza yozuvidan avtomat test." },
    { when: '2026 / III', what: 'LMS integratsiyasi (1S, Moodle) va API.' },
    { when: '2027', what: 'Respublika miqyosida maktab piloti; maqola va monografiya.' }
  ]
};

export const team = {
  kicker: '07 — Jamoa',
  title: "To'rt kishi, bitta stol",
  people: [
    { initials: 'IS', name: '[Ism Familiya]', role: 'Loyiha rahbari · model' },
    { initials: 'AL', name: '[Ism]', role: 'Backend va infratuzilma' },
    { initials: 'PB', name: '[Ism]', role: 'Panel va vizualizatsiya' },
    { initials: 'MF', name: '[Ism]', role: 'Pedagogika, metodologiya' }
  ]
};

export const conclusion = {
  kicker: '08 — Yakun',
  title: 'Uch asosiy xulosa',
  points: [
    "Kech feedback — tuzatish mumkin bo'lgan xato emas, yo'qolgan imkoniyat.",
    'AI professor o\'rnini bosmaydi: 6 soatlik ishni 0.4 soatga tushiradi, qolgan vaqtni muloqotga qaytaradi.',
    "9 haftalik pilot gipotezani tasdiqladi — tizim boshqa fakultetga ko'chirishga tayyor."
  ],
  thanks: 'E\'tiboringiz uchun rahmat.'
};

export const slides = [
  { id: 'kirish', title: 'Kirish', hero: true },
  { id: 'muammo', title: 'Muammo' },
  { id: 'yechim', title: 'Yechim', split: true },
  { id: 'arxitektura', title: 'Arxitektura' },
  { id: 'natijalar', title: 'Natijalar', split: true },
  { id: 'etika', title: 'Etika' },
  { id: 'reja', title: 'Reja' },
  { id: 'jamoa', title: 'Jamoa' },
  { id: 'yakun', title: 'Yakun' }
];

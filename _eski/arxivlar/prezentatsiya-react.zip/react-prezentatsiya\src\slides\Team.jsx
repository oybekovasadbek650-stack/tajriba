import { Reveal } from '../components/Reveal.jsx';
import { FillIn } from '../components/FillIn.jsx';
import { team } from '../data/content.js';

export function Team() {
  return (
    <>
      <Reveal as="p" className="kicker">{team.kicker}</Reveal>
      <Reveal as="h2">{team.title}</Reveal>

      <div className="grid g4 stagger">
        {team.people.map((p, i) => (
          <Reveal className="person" key={p.initials} i={i}>
            <i><FillIn id={`ini${i}`}>{p.initials}</FillIn></i>
            <h3><FillIn id={`team${i}`}>{p.name}</FillIn></h3>
            <p>{p.role}</p>
          </Reveal>
        ))}
      </div>
    </>
  );
}

import { useEffect, useRef, useState } from 'react';

const KEY = 'algora-fillin-v1';

/* Bo'sh joylarni bosib yozish va brauzerda saqlash. */
export function FillIn({ id, children }) {
  const [text, setText] = useState(children);
  const [editing, setEditing] = useState(false);
  const el = useRef(null);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    if (saved[id]) setText(saved[id]);
  }, [id]);

  const finish = () => {
    const next = el.current ? el.current.textContent.trim() : text;
    setText(next);
    setEditing(false);
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    saved[id] = next;
    localStorage.setItem(KEY, JSON.stringify(saved));
  };

  return (
    <span
      ref={el}
      className="fillin"
      title="Bosing — o'zingizning ma'lumotingizni yozing"
      contentEditable={editing}
      suppressContentEditableWarning
      onBlur={finish}
      onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); e.currentTarget.blur(); } }}
      onClick={() => { setEditing(true); el.current?.focus(); }}
    >
      {text}
    </span>
  );
}

# Algora — prezentatsiya dek (React + Vite)

Universitetda ma'ruza qilish uchun scroll'li, jonli fonli prezentatsiya sayti.
React 19 + Vite. Build qilingan holda `file://` orqali ham ochiladi.

## Ishga tushirish

```bash
npm install       # bir marta
npm run dev       # http://localhost:5174 — tahrirlab turib ko'rish uchun
npm run build     # dist/ papkasiga statik versiya
npm run preview   # dist/ ni lokal serverda tekshirish
```

`npm run build` dan keyin `dist/index.html` faylini oddiy ikki marta bosib
ochsa ham ishlaydi (internet ham shart emas, faqat shriftlar yuklanmaydi).

## Matnni o'zgartirish

**Butun matn bitta faylda: `src/data/content.js`.**
Universitet nomi, ismlar, raqamlar, slaydlar ketma-ketligi — o'sha yerda.
Komponentlarga tegish shart emas.

Slayd qo'shish: `src/slides/` ichiga yangi komponent yozib, `App.jsx`
dagi `DECK` ro'yxatiga va `content.js` dagi `slides` ro'yxatiga qo'shing.

## Boshqaruv

| Tugma | Vazifa |
|---|---|
| `←` `→` `Space` `PageUp/Down` | slayd almashish |
| `1`–`9` | shu slaydga sakrash |
| `Home` / `End` | birinchi / oxirgi slayd |
| `F` | fullscreen |
| `P` | PDF (Print) |
| `Esc` | ma'ruza rejimidan chiqish |

Yuqori o'ngdagi tugma — **ma'ruza rejimi** (fonni tinchlantiradi, yon
yo'liqda slayd nomini ko'rsatadi).

## Bo'sh joylarni to'ldirish

`[Ism Familiya]` kubi kvadrat qavsli joylarni **bosib** yozsa bo'ladi —
matn brauzeringizda (`localStorage`) saqlanadi. Doimiy o'zgartirish uchun
`content.js` ni tahrirlang.

## Diqqat

Slaydlardagi raqamlar (142 talaba, 38%, p < 0.01) — **namunaviy ma'lumot**.
Haqiqiy himoyada ularni o'zingizning ölçov natijalaringiz bilan almashtiring
(`content.js` → `results`).

## Tuzilma

```
src/
  main.jsx              kirish nuqtasi
  App.jsx               dek: slaydlar ro'yxati + dvijok ulanishi
  styles.css            butun dizayn (animatsiyalar shu yerda)
  data/content.js       ← BUTUN MATN SHU YERDA
  lib/useInView.js      IntersectionObserver hook'i (scroll reveal)
  lib/useDeck.js        faol slayd, progress, klaviatura, ma'ruza rejimi
  components/
    Background.jsx      aurora + yong'ul tori (canvas) + kursor dog'i
    Reveal.jsx          <Reveal> va <Rich> (matn ichida {emphasis})
    CountUp.jsx         raqam o'sishi
    Chart.jsx           animatsion chiziq diagrammasi
    FillIn.jsx          bosib to'ldiriladigan maydon
    Nav.jsx             panel + progress + yon yo'liq
  slides/               9 ta slayd komponenti
```
